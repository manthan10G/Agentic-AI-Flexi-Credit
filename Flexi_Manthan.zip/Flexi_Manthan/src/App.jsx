import { useState } from 'react'

function App() {
  const [reviews, setReviews] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [results, setResults] = useState(null)

  // Load from .env using Vite's import.meta.env
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY

  const analyzeReviews = async () => {
    if (!apiKey) {
      setError({ title: 'API Key Missing', message: 'VITE_GEMINI_API_KEY is not defined in .env file.' })
      return
    }

    if (!reviews.trim()) {
      setError({ title: 'Input Required', message: 'Please paste some customer reviews to analyze.' })
      return
    }

    setLoading(true)
    setError(null)
    setResults(null)

    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`

      const prompt = `You are an expert customer review analyst. Analyze the following customer reviews. Return ONLY a valid JSON object without any markdown formatting, backticks, or code blocks. The JSON must match this exact structure:
{
  "overallSentiment": "Positive" | "Negative" | "Neutral" | "Mixed",
  "sentimentScore": <number between 0 and 100, where 0 is extremely negative and 100 is extremely positive>,
  "keyThemes": ["theme 1", "theme 2", "theme 3"],
  "actionableFeedback": ["feedback 1", "feedback 2"],
  "summary": "A concise executive summary paragraph."
}

Reviews to analyze:
"${reviews.trim()}"`

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }]
        })
      })

      if (!response.ok) {
        const errData = await response.json()
        throw new Error(errData.error?.message || `HTTP Error ${response.status}`)
      }

      const data = await response.json()
      let jsonText = data.candidates[0].content.parts[0].text

      // Cleanup markdown if AI adds it
      jsonText = jsonText.replace(/```json/g, '').replace(/```/g, '').trim()

      const parsed = JSON.parse(jsonText)
      setResults(parsed)
    } catch (err) {
      console.error(err)
      setError({
        title: 'Analysis Failed',
        message: err.message || 'Failed to communicate with Gemini API. Check your key or try again.'
      })
    } finally {
      setLoading(false)
    }
  }

  const getSentimentEmoji = (sentiment) => {
    if (!sentiment) return '😐'
    const s = sentiment.toLowerCase()
    if (s === 'positive') return '🤩'
    if (s === 'negative') return '😠'
    if (s === 'mixed') return '🤔'
    return '😐'
  }

  const getSentimentColor = (sentiment) => {
    if (!sentiment) return 'var(--warning-color)'
    const s = sentiment.toLowerCase()
    if (s === 'positive') return 'var(--success-color)'
    if (s === 'negative') return 'var(--danger-color)'
    if (s === 'mixed') return '#a855f7'
    return 'var(--warning-color)'
  }

  return (
    <>
      <div className="background-elements">
        <div className="blob blob-1"></div>
        <div className="blob blob-2"></div>
        <div className="blob blob-3"></div>
      </div>

      <header className="app-header">
        <div className="container">
          <h1><span className="gradient-text">Nova</span> Review Analytics</h1>
          <p>AI-powered customer feedback intelligence using Gemini.</p>
        </div>
      </header>

      <main className="container main-content">
        {/* Input Card */}
        <section className="card input-section">
          <div className="card-header">
            <h2>Customer Reviews</h2>
            <span className="badge">Input</span>
          </div>
          <div className="input-group">
            <label htmlFor="reviewsInput">Paste reviews below</label>
            <textarea
              id="reviewsInput"
              value={reviews}
              onChange={(e) => setReviews(e.target.value)}
              placeholder="Paste your customer reviews here...&#10;E.g. 'I absolutely loved the product, but the shipping was a bit slow and the packaging was damaged.'"
            />
          </div>
          <button
            className="btn btn-primary"
            onClick={analyzeReviews}
            disabled={loading}
          >
            {loading ? 'Analyzing...' : (
              <>
                <span className="btn-text">Analyze Reviews</span>
                <span className="btn-icon">✨</span>
              </>
            )}
          </button>
        </section>

        {/* Loading State */}
        {loading && (
          <div className="loading-state">
            <div className="spinner"></div>
            <p>Analyzing feedback with Gemini AI...</p>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="error-state">
            <div className="error-icon">⚠️</div>
            <h3>{error.title}</h3>
            <p>{error.message}</p>
          </div>
        )}

        {/* Results Card */}
        {results && (
          <section className="results-section">
            <div className="dashboard-grid">

              {/* Overview Card */}
              <div className="card overview-card glass">
                <h3>Overall Sentiment</h3>
                <div className="sentiment-display">
                  <div className="sentiment-emoji">
                    {getSentimentEmoji(results.overallSentiment)}
                  </div>
                  <div className="sentiment-info">
                    <h2 className={results.overallSentiment?.toLowerCase() || 'neutral'}>
                      {results.overallSentiment || 'Neutral'}
                    </h2>
                    <div className="progress-bar">
                      <div
                        className="progress-fill"
                        style={{
                          width: `${results.sentimentScore || 50}%`,
                          background: `linear-gradient(90deg, var(--primary-color), ${getSentimentColor(results.overallSentiment)})`
                        }}
                      />
                    </div>
                    <span className="score-text">{results.sentimentScore || 50} / 100</span>
                  </div>
                </div>
              </div>

              {/* Summary Card */}
              <div className="card summary-card glass">
                <h3>Executive Summary</h3>
                <p className="summary-text">
                  {results.summary || 'No summary provided.'}
                </p>
              </div>

              {/* Themes Card */}
              <div className="card themes-card glass">
                <h3>Key Themes</h3>
                <ul className="tag-list">
                  {results.keyThemes && results.keyThemes.length > 0 ? (
                    results.keyThemes.map((theme, idx) => (
                      <li key={idx} style={{ animationDelay: `${idx * 0.1}s` }}>
                        {theme}
                      </li>
                    ))
                  ) : (
                    <li>No themes identified</li>
                  )}
                </ul>
              </div>

              {/* Actionable Feedback Card */}
              <div className="card feedback-card glass">
                <h3>Actionable Feedback</h3>
                <ul className="action-list">
                  {results.actionableFeedback && results.actionableFeedback.length > 0 ? (
                    results.actionableFeedback.map((feedback, idx) => (
                      <li key={idx} style={{ animationDelay: `${idx * 0.1}s` }}>
                        {feedback}
                      </li>
                    ))
                  ) : (
                    <li>No actionable feedback found</li>
                  )}
                </ul>
              </div>

            </div>
          </section>
        )}
      </main>
    </>
  )
}

export default App
